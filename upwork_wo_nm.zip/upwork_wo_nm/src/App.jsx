import React from 'react'
import Navbar from './components/Navbar/navbar'
import SubNavbar from './components/sub_navbar/SubNavbar'
import Home from './screens/Home'

const App = () => {
  return (
    <>
      <Home />
    </>)
}

export default App
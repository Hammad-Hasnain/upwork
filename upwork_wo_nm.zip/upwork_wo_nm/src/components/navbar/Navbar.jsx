import React from 'react'
import { logo } from '../../assets/images'
import { FiSearch } from 'react-icons/fi'
import { navLinks } from '../../utlities/content'
import { GoChevronDown, GoChevronUp } from 'react-icons/go'


const Navbar = () => {

    return (
        <nav className='flex justify-between items-center p-4 border'>
            <div className='flex gap-5 '>
                <img src={logo} alt="" className='w-[82px]' />
                <ul className='flex gap-5'>
                    {navLinks.map((e, i) => <li >
                        <button className='flex items-center'>
                            <span>{e.link}</span>
                            <GoChevronDown />
                        </button>
                    </li>)}
                    <li >
                        <button className='flex items-center'>
                            <span>Find talent</span>
                            <GoChevronDown />
                        </button>
                    </li>

                    <li>Enterprise</li>
                </ul>
            </div>
            <div className='flex gap-5'>
                <div className='border-[2px]  flex items-center gap-3 p-2 rounded-[25px]'>
                    <FiSearch />
                    <input type="text" placeholder='Search....' className='outline-none' />
                    <div className='border h-full' />
                    <button className='flex items-center'>
                        <span>Talent</span>
                        <GoChevronUp />
                    </button>
                </div>
                <button>Log in</button>
                <button className='bg-[#108a00] text-white rounded-[10px] py-2 px-5'>Sign up</button>
            </div>
        </nav>
    )
}

export default Navbar
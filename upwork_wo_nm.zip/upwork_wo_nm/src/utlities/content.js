export const navLinks = [{
    link: 'Find talent',
    isHovered: false,
},
{
    link: 'Find work',
    isHovered: false,
},
{
    link: 'Why Upwork',
    isHovered: false,
},
{
    link: `What's new`,
    isHovered: false,
},
{
    link: 'Enterprise',
    isHovered: false,
},
]
export const subNavLinks = [{
    link: 'Development & IT',
    isHovered: false,
},
{
    link: 'AI Services',
    isHovered: false,
},
{
    link: 'Design & Creative',
    isHovered: false,
},
{
    link: 'Sales & Marketing',
    isHovered: false,
},
{
    link: 'Admin & Cutomer Support',
    isHovered: false,
},
]
import React from 'react'
import { logo } from '../../assets/images'
import { FiSearch } from 'react-icons/fi'
import { navLinks } from '../../utlities/content'
import { GoChevronDown, GoChevronUp } from 'react-icons/go'
import { LiaFacebook } from 'react-icons/lia'
import { FaXTwitter } from 'react-icons/fa6'
import { FaInstagram, FaLinkedin, FaYoutube } from 'react-icons/fa'
import { PiAppleLogoLight } from 'react-icons/pi'
import { IoLogoAndroid } from 'react-icons/io'


const Footer = () => {

    return (
        <footer className='bg-[#181818] p-[5em] mx-[20px] rounded-[7px]'>
            <div className='grid grid-cols-12 '>
                <div className="col-span-3">
                    <ul>
                        <li className='text-[white] text-[13px] mb-[20px]'>For Clients</li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>How to hire</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Talent Marketplace</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Project Catalog</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Hire an agency</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Enterprise</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Any Hire</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Contract-to-hire</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Direct Contracts</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Hire worldwide</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Hire in the USA</a></li>
                    </ul>
                </div>
                <div className="col-span-3">
                    <ul>
                        <li className='text-[white] text-[13px] mb-[20px]'>For Talent</li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>How to find work</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Direct Contracts</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Find freelance jobs worldwide</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Find freelance jobs in the USA</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Win work with ads</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Exclusive resources with Freelancer Plus</a></li>
                    </ul>
                </div>
                <div className="col-span-3">
                    <ul>
                        <li className='text-[white] text-[13px] mb-[20px]'>Help & support</li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Success stories</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Upwork reviews</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Resources</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Blog</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Community</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Affiliate programme</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Free Business Tools</a></li>
                    </ul>
                </div>
                <div className="col-span-3">
                    <ul>
                        <li className='text-[white] text-[13px] mb-[20px]'>About us</li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Leadership</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Investor relations</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Careers</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Our impact</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Press</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Contact us</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Partners</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Trust, safety & security</a></li>
                        <li><a href="#" className='text-[white] text-[13px] hover:underline'>Modern slavery statement</a></li>
                    </ul>
                </div>
            </div>
            <div className='flex justify-between' >
                <div className='flex items-center gap-[10px] mt-[3em]'>
                    <h6 className='font-[500] text-[white] '>Follow us</h6>
                    <a href='#' className='p-[5px] border rounded-[50%] cursor-pointer hover:bg-[#a5a5a5]'><LiaFacebook className='text-[white] text-[25px]' /></a>
                    <a href='#' className='p-[5px] border rounded-[50%] cursor-pointer hover:bg-[#a5a5a5]'><FaLinkedin className='text-[white] text-[25px]' /></a>
                    <a href='#' className='p-[5px] border rounded-[50%] cursor-pointer hover:bg-[#a5a5a5]'><FaXTwitter className='text-[white] text-[25px]' /></a>
                    <a href='#' className='p-[5px] border rounded-[50%] cursor-pointer hover:bg-[#a5a5a5]'><FaYoutube className='text-[white] text-[25px]' /></a>
                    <a href='#' className='p-[5px] border rounded-[50%] cursor-pointer hover:bg-[#a5a5a5]'><FaInstagram className='text-[white] text-[25px]' /></a>
                </div>
                <div className='flex items-center gap-[10px] mt-[3em]'>
                    <h6 className='font-[500] text-[white] '>Mobile App</h6>
                    <a href='#' className='p-[5px] border rounded-[50%] cursor-pointer hover:bg-[#a5a5a5]'><PiAppleLogoLight className='text-[white] text-[25px]' /></a>
                    <a href='#' className='p-[5px] border rounded-[50%] cursor-pointer hover:bg-[#a5a5a5]'><IoLogoAndroid className='text-[white] text-[25px]' /></a>
                </div>
            </div>
            <hr className='my-[20px]' />
            <div className='flex gap-[40px]'>
                <p className='text-[white]'>© 2015 - 2024 Upwork® Global Inc.</p>
                <ul className='flex gap-[20px]'>
                    <li><a href="#" className='text-[white]'>Terms of Service</a></li>
                    <li><a href="#" className='text-[white]'>Privacy Policy</a></li>
                    <li><a href="#" className='text-[white]'>CA Notice at Collection</a></li>
                    <li><a href="#" className='text-[white]'>Cookie Settings</a></li>
                    <li><a href="#" className='text-[white]'>Accessibility</a></li>
                </ul>
            </div>
        </footer>
    )
}

export default Footer